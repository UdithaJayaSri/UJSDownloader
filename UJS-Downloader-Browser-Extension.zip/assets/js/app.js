/* UJS Downloader website: small, dependency-free enhancements. The site works without any of this. */
(function () {
  'use strict';
  var doc = document;

  /* mobile menu */
  var toggle = doc.querySelector('.nav-toggle');
  var links = doc.getElementById('nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    links.addEventListener('click', function (e) {
      if (e.target.closest('a')) { links.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); }
    });
  }

  /* the menu also closes with Escape or a tap outside it */
  doc.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && links && links.classList.contains('open')) { links.classList.remove('open'); if (toggle) { toggle.setAttribute('aria-expanded', 'false'); toggle.focus(); } }
  });
  doc.addEventListener('click', function (e) {
    if (links && links.classList.contains('open') && !e.target.closest('.nav')) { links.classList.remove('open'); if (toggle) { toggle.setAttribute('aria-expanded', 'false'); } }
  });

  /* the main button follows the visitor's device */
  var cta = doc.getElementById('cta-primary');
  if (cta) {
    var ua = navigator.userAgent || '';
    var label = cta.querySelector('[data-label]');
    if (/Android/i.test(ua)) {
      cta.href = cta.getAttribute('data-and') || cta.href;
      if (label) { label.textContent = 'Download for Android'; }
    } else if (/iPhone|iPad|iPod|Macintosh|Linux/i.test(ua) && !/Windows/i.test(ua)) {
      cta.href = '#download';
      if (label) { label.textContent = 'See downloads'; }
    }
  }

  /* platform tabs */
  var tabs = doc.querySelectorAll('.tabs [role="tab"]');
  var panels = doc.querySelectorAll('.panel');
  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var key = tab.getAttribute('data-tab');
      tabs.forEach(function (t) { t.setAttribute('aria-selected', t === tab ? 'true' : 'false'); });
      panels.forEach(function (p) {
        var on = p.getAttribute('data-panel') === key;
        p.classList.toggle('on', on);
        if (on) { p.classList.add('in'); }
      });
    });
  });

  /* numbers count up when they scroll into view */
  function countUp(el) {
    var target = parseInt(el.getAttribute('data-count'), 10) || 0;
    if (target < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
    var start = null, dur = 1200;
    function step(ts) {
      if (start === null) { start = ts; }
      var p = Math.min((ts - start) / dur, 1);
      var v = Math.round(target * (1 - Math.pow(1 - p, 3)));
      el.textContent = v.toLocaleString('en-US');
      if (p < 1) { requestAnimationFrame(step); }
    }
    requestAnimationFrame(step);
  }

  /* reveal on scroll */
  var items = doc.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) { return; }
        en.target.classList.add('in');
        en.target.querySelectorAll('[data-count]').forEach(countUp);
        if (en.target.hasAttribute('data-count')) { countUp(en.target); }
        io.unobserve(en.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add('in'); });
  }

  /* sticky "Download free" bar on phones: shown once the first screen and the download cards are out of view */
  var bar = doc.getElementById('mobile-cta');
  var heroEl = doc.querySelector('.hero');
  var dlEl = doc.getElementById('download');
  if (bar && heroEl && dlEl && 'IntersectionObserver' in window) {
    var heroIn = true, dlIn = false;
    var update = function () {
      var show = !heroIn && !dlIn;
      bar.classList.toggle('show', show);
      bar.setAttribute('aria-hidden', show ? 'false' : 'true');
      var a = bar.querySelector('a');
      if (a) { a.tabIndex = show ? 0 : -1; }
      doc.body.classList.toggle('has-cta', show);
    };
    new IntersectionObserver(function (en) { heroIn = en[0].isIntersecting; update(); }).observe(heroEl);
    new IntersectionObserver(function (en) { dlIn = en[0].isIntersecting; update(); }, { threshold: 0.15 }).observe(dlEl);
  }

  /* video page: chapters jump to a time, the current chapter is highlighted */
  var tour = doc.getElementById('tour-video');
  var chBtns = doc.querySelectorAll('[data-seek]');
  if (tour && chBtns.length) {
    chBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        tour.currentTime = parseFloat(btn.getAttribute('data-seek')) || 0;
        var p = tour.play(); if (p && p.catch) { p.catch(function () { /* needs a tap */ }); }
        tour.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
    });
    tour.addEventListener('timeupdate', function () {
      var t = tour.currentTime, active = null;
      chBtns.forEach(function (b) { if (parseFloat(b.getAttribute('data-seek')) <= t + 0.3) { active = b; } });
      chBtns.forEach(function (b) { b.classList.toggle('on', b === active); });
    });
  }
  /* only one video plays at a time */
  var vids = doc.querySelectorAll('video');
  vids.forEach(function (v) {
    v.addEventListener('play', function () { vids.forEach(function (o) { if (o !== v) { o.pause(); } }); });
  });
  /* YouTube: nothing loads from YouTube until the visitor taps play */
  doc.querySelectorAll('[data-yt]').forEach(function (el) {
    el.addEventListener('click', function () {
      var f = doc.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(el.getAttribute('data-yt')) + '?autoplay=1&rel=0';
      f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      f.allowFullscreen = true;
      f.title = el.getAttribute('data-title') || 'Video';
      el.replaceWith(f);
    });
  });

  /* ads: only after the visitor has made a choice (see the cookie notice) */
  var cfg = window.UJS || {};
  if (cfg.ads && cfg.client) {
    var KEY = 'ujs-consent';
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) { /* storage blocked */ }
    var box = doc.getElementById('consent');

    function loadAds(personalised) {
      window.adsbygoogle = window.adsbygoogle || [];
      if (!personalised) { window.adsbygoogle.requestNonPersonalizedAds = 1; }
      var s = doc.createElement('script');
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(cfg.client);
      doc.head.appendChild(s);
      doc.querySelectorAll('[data-ad]').forEach(function (w) {
        w.hidden = false;
        try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { /* ad blocked */ }
      });
    }

    if (saved === 'all' || saved === 'basic') {
      loadAds(saved === 'all');
    } else if (box) {
      box.hidden = false;
      box.addEventListener('click', function (e) {
        var b = e.target.closest('[data-consent]');
        if (!b) { return; }
        var v = b.getAttribute('data-consent');
        try { localStorage.setItem(KEY, v); } catch (err) { /* storage blocked */ }
        box.hidden = true;
        loadAds(v === 'all');
      });
    }
  }
})();
