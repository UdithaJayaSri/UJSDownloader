<?php
require_once __DIR__ . '/inc/lib.php';
http_response_code(404);
$page = ['title' => 'Page not found', 'path' => '404.php', 'noindex' => true];
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow center">
    <p class="big404">404</p>
    <h1>We could not find that page</h1>
    <p class="lead">The link may be old or mistyped.</p>
    <p><a class="btn" href="<?= h(u('')) ?>">Back to the home page</a></p>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
