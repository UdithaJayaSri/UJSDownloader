<?php
require_once __DIR__ . '/inc/lib.php';
$page = [
    'title' => 'Contact',
    'description' => 'Questions, bug reports or ideas for UJS Downloader? Get in touch.',
    'path' => 'contact.php',
];
$email = cfg('contact_email');
$wa = preg_replace('/\D/', '', (string)cfg('contact_whatsapp', ''));
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow">
    <div class="sec-head left"><span class="eyebrow">Contact</span><h1>Get in touch</h1><p>Questions, bug reports or ideas? We read every message.</p></div>
    <div class="contact-cards">
      <?php if ($email): ?>
      <a class="contact-card" href="mailto:<?= h($email) ?>"><?= icon('mail', 28) ?><div><b>Email</b><span><?= h($email) ?></span></div></a>
      <?php endif; ?>
      <?php if ($wa): ?>
      <a class="contact-card" href="https://wa.me/<?= h($wa) ?>" rel="noopener"><?= icon('chat', 28) ?><div><b>WhatsApp</b><span>Message <?= h(cfg('developer')) ?></span></div></a>
      <?php endif; ?>
      <?php if (cfg('developer_url')): ?>
      <a class="contact-card" href="<?= h(cfg('developer_url')) ?>" target="_blank" rel="noopener"><?= icon('globe', 28) ?><div><b>Developer</b><span><?= h(cfg('developer')) ?> &middot; portfolio</span></div></a>
      <?php endif; ?>
    </div>
    <div class="prose">
      <h2>When you report a problem, please tell us</h2>
      <ul class="bul">
        <li>Which app: Windows, Android or the Chrome button, and its version (see About in the app).</li>
        <li>Which website the link was from (YouTube, TikTok, Facebook or Instagram).</li>
        <li>What you expected, and what happened instead. A screenshot helps a lot.</li>
      </ul>
      <p>Please do not send passwords or private links.</p>
    </div>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
