<?php
require_once __DIR__ . '/inc/lib.php';
$dl = downloads_cfg();
$totals = all_download_totals();
$grand = array_sum($totals);
$showCounts = (bool)cfg('show_public_counts', true);
$winOk = download_available('windows');
$andOk = download_available('android');
$winHref = $winOk ? u('download.php?f=windows') : '#download';
$andHref = $andOk ? u('download.php?f=android') : '#download';

$page = [
    'home' => true,
    'path' => '',
    'nav'  => 'home',
    'jsonld' => [
        [
            '@context' => 'https://schema.org',
            '@type' => 'SoftwareApplication',
            'name' => cfg('site_name'),
            'applicationCategory' => 'MultimediaApplication',
            'operatingSystem' => 'Windows 10, Windows 11, Android 7.0+',
            'description' => 'Free video downloader for YouTube, TikTok, Facebook and Instagram with playlist picker, trimming, queue and up to 4K quality.',
            'offers' => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD'],
            'author' => ['@type' => 'Person', 'name' => cfg('developer'), 'url' => cfg('developer_url')],
            'url' => site_url(''),
            'image' => site_url('assets/img/og-image.png'),
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => cfg('site_name'),
            'url' => site_url(''),
        ],
    ],
];
require __DIR__ . '/inc/header.php';

$features = [
    ['layers',   'Playlists and channels',   'Open a whole playlist or channel, see thumbnails, titles and lengths, tick the videos you want or take them all (up to 300).'],
    ['scissors', 'Trim before you save',     'Drag two handles to keep only the part you want, and preview it right inside the app. No editing software needed.'],
    ['music',    'Up to 4K, or MP3',         'Choose the quality you like, or save just the audio as MP3 with the cover art and title already inside.'],
    ['list',     'Queue and batch',          'Paste many links at once. They download in order, and anything that failed can be retried in one tap.'],
    ['clipboard','Clipboard pop-up',         'Copy a link anywhere and a small offer appears: download it now or add it to the queue. No pasting needed.'],
    ['mouse',    'A button on YouTube',      'The Chrome button sits right under every video, next to Share. One click sends the video to the app.'],
    ['lock',     'Your own account',         'Sign in once inside the app to save videos that need a login. Your session stays on your device.'],
    ['wifi',     'Speed and Wi-Fi control',  'Limit the speed, download only on Wi-Fi, and keep files tidy in a folder per site and channel.'],
    ['clock',    'History and sharing',      'Everything you saved in one list: open it, show it in its folder, share it or remove it.'],
];
?>
<section class="hero">
  <div class="hero-bg" aria-hidden="true"><span class="orb o1"></span><span class="orb o2"></span><span class="orb o3"></span><div class="gridlines"></div></div>
  <div class="wrap hero-grid">
    <div class="hero-copy reveal">
      <span class="pill"><span class="pulse"></span> New: a download button right under YouTube videos</span>
      <h1>Paste a link.<br><span class="grad">Get the video.</span></h1>
      <p class="lead">The free downloader for YouTube, TikTok, Facebook and Instagram. Pick videos from whole playlists, trim clips before you save them and download up to 4K, on Windows, on Android and inside Chrome.</p>
      <div class="cta-row">
        <a class="btn btn-lg" id="cta-primary" href="<?= h($winHref) ?>" data-win="<?= h($winHref) ?>" data-and="<?= h($andHref) ?>"><?= icon('download', 20) ?> <span data-label>Download for Windows</span></a>
        <a class="btn btn-lg btn-ghost" href="#download">All downloads</a>
      </div>
      <ul class="trust">
        <li><?= icon('check', 16) ?> 100% free</li>
        <li><?= icon('check', 16) ?> No ads in the app</li>
        <li><?= icon('check', 16) ?> No sign-up</li>
        <li><?= icon('check', 16) ?> Runs on your device</li>
      </ul>
      <?php if ($showCounts && $grand > 0): ?>
      <p class="hero-count"><b data-count="<?= (int)$grand ?>"><?= fmt_num($grand) ?></b> downloads so far</p>
      <?php endif; ?>
    </div>
    <div class="hero-visual reveal" aria-hidden="true">
      <div class="win-mock">
        <div class="win-bar"><i></i><i></i><i></i><span>UJS Downloader</span></div>
        <img src="<?= h(u('assets/img/app-home.png')) ?>" width="1180" height="760" alt="" fetchpriority="high">
      </div>
      <div class="phone-mock">
        <img src="<?= h(u('assets/img/app-android-home.png')) ?>" width="720" height="1560" alt="">
      </div>
      <span class="chip c-yt">YouTube</span>
      <span class="chip c-tt">TikTok</span>
      <span class="chip c-fb">Facebook</span>
      <span class="chip c-ig">Instagram</span>
    </div>
  </div>
</section>

<?php ad_slot('top'); ?>

<section class="stats" aria-label="At a glance">
  <div class="wrap stats-grid">
    <div><b>4</b><span>sites supported</span></div>
    <div><b>4K</b><span>top quality</span></div>
    <div><b>300</b><span>videos from one playlist</span></div>
    <div><b>3</b><span>ways to use it</span></div>
  </div>
</section>

<section class="sec" id="features">
  <div class="wrap">
    <div class="sec-head reveal">
      <span class="eyebrow">Features</span>
      <h2>Everything a video downloader should do</h2>
      <p>Built for people who save a lot of videos and want it to just work.</p>
    </div>
    <div class="cards">
      <?php foreach ($features as $i => $f): ?>
      <article class="card reveal" style="--d:<?= ($i % 3) * 80 ?>ms">
        <span class="ico"><?= icon($f[0], 26) ?></span>
        <h3><?= h($f[1]) ?></h3>
        <p><?= h($f[2]) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php ad_slot('inline'); ?>

<section class="sec sec-alt" id="how">
  <div class="wrap">
    <div class="sec-head reveal">
      <span class="eyebrow">How it works</span>
      <h2>Three steps, about ten seconds</h2>
    </div>
    <ol class="steps">
      <li class="reveal"><span class="num">1</span><h3>Copy the link</h3><p>Copy the address of any video, playlist or channel from YouTube, TikTok, Facebook or Instagram.</p></li>
      <li class="reveal" style="--d:100ms"><span class="num">2</span><h3>Paste and choose</h3><p>Paste it into the app. Pick the quality, trim the part you want, or tick the videos from a playlist.</p></li>
      <li class="reveal" style="--d:200ms"><span class="num">3</span><h3>Save it</h3><p>Press Download. The video lands in a tidy folder on your device, ready to watch anywhere, offline.</p></li>
    </ol>
  </div>
</section>

<?php $tour = isset(cfg('videos')['tour']) ? cfg('videos')['tour'] : null; if ($tour): ?>
<section class="sec sec-alt" id="watch">
  <div class="wrap">
    <div class="sec-head reveal">
      <span class="eyebrow">Watch</span>
      <h2>See it in action</h2>
      <p>A five-minute tour of the Windows app, the Chrome button and the Android app.</p>
    </div>
    <a class="video-teaser reveal" href="<?= h(u('watch.php')) ?>" aria-label="Watch the <?= h($tour['length']) ?> tour">
      <img loading="lazy" src="<?= h(u($tour['poster'])) ?>" width="1280" height="720" alt="">
      <span class="play"><?= icon('play', 34) ?></span>
      <span class="len"><?= h($tour['length']) ?></span>
    </a>
    <p class="more"><a href="<?= h(u('watch.php')) ?>">Watch the videos &rarr;</a></p>
  </div>
</section>
<?php endif; ?>

<section class="sec" id="platforms">
  <div class="wrap">
    <div class="sec-head reveal">
      <span class="eyebrow">Everywhere you are</span>
      <h2>One app, three ways to use it</h2>
      <p>The same features on your computer, on your phone, and one click away in your browser.</p>
    </div>
    <div class="tabs reveal" role="tablist" aria-label="Platforms">
      <button role="tab" aria-selected="true" data-tab="win" type="button"><?= icon('monitor', 18) ?> Windows</button>
      <button role="tab" aria-selected="false" data-tab="and" type="button"><?= icon('phone', 18) ?> Android</button>
      <button role="tab" aria-selected="false" data-tab="ext" type="button"><?= icon('puzzle', 18) ?> Chrome button</button>
    </div>
    <div class="tab-panels">
      <div class="panel on reveal" data-panel="win">
        <div class="panel-copy">
          <h3>A full desktop app</h3>
          <ul class="ticks">
            <li><?= icon('check', 18) ?> Playlist and channel picker with thumbnails</li>
            <li><?= icon('check', 18) ?> Trim with a live preview</li>
            <li><?= icon('check', 18) ?> Queue, history and a clipboard pop-up</li>
            <li><?= icon('check', 18) ?> One-click installer, no administrator needed</li>
          </ul>
          <a class="btn" href="#download"><?= icon('download', 18) ?> Get the Windows app</a>
        </div>
        <div class="panel-art"><div class="win-mock"><div class="win-bar"><i></i><i></i><i></i><span>UJS Downloader</span></div><img loading="lazy" src="<?= h(u('assets/img/app-queue.png')) ?>" width="1180" height="760" alt="The UJS Downloader Windows app with the download queue open"></div></div>
      </div>
      <div class="panel reveal" data-panel="and">
        <div class="panel-copy">
          <h3>Made for your phone</h3>
          <ul class="ticks">
            <li><?= icon('check', 18) ?> Same picker and trimming, built for touch</li>
            <li><?= icon('check', 18) ?> Copy a link and the app offers to save it</li>
            <li><?= icon('check', 18) ?> Downloads keep going in the background</li>
            <li><?= icon('check', 18) ?> Share a finished video straight from History</li>
          </ul>
          <a class="btn" href="#download"><?= icon('download', 18) ?> Get the Android app</a>
        </div>
        <div class="panel-art"><div class="phone-mock static"><img loading="lazy" src="<?= h(u('assets/img/app-android-home.png')) ?>" width="720" height="1560" alt="The UJS Downloader Android app"></div></div>
      </div>
      <div class="panel reveal" data-panel="ext">
        <div class="panel-copy">
          <h3>A button under every YouTube video</h3>
          <ul class="ticks">
            <li><?= icon('check', 18) ?> Sits in the row next to Like, Share and Save</li>
            <li><?= icon('check', 18) ?> Choose quality and trim, download now, or queue it</li>
            <li><?= icon('check', 18) ?> Works in Chrome, Edge and Brave</li>
            <li><?= icon('check', 18) ?> Comes with the Windows app, or add it on its own</li>
          </ul>
          <a class="btn" href="<?= h(u('guide.php#extension')) ?>"><?= icon('puzzle', 18) ?> How to add it</a>
        </div>
        <div class="panel-art">
          <div class="yt-mock" aria-label="The UJS Download button in the YouTube action row">
            <div class="yt-title"></div><div class="yt-title short"></div>
            <div class="yt-row">
              <span class="yt-pill">Like</span>
              <span class="yt-pill">Share</span>
              <span class="yt-ujs"><?= icon('download', 16) ?> UJS Download <i><?= icon('chevron', 13) ?></i></span>
              <span class="yt-pill">Save</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="sec sec-alt" id="download">
  <div class="wrap">
    <div class="sec-head reveal">
      <span class="eyebrow">Download</span>
      <h2>Get UJS Downloader, free</h2>
      <p>Pick your device. No account, no payment.</p>
    </div>
    <div class="dl-grid">
      <?php
      $order = [['windows', 'monitor'], ['android', 'phone'], ['extension', 'puzzle']];
      foreach ($order as $i => $o):
          $k = $o[0];
          if (!isset($dl[$k])) { continue; }
          $c = $dl[$k];
          $ok = download_available($k);
      ?>
      <article class="dl-card reveal" style="--d:<?= $i * 90 ?>ms">
        <span class="ico big"><?= icon($o[1], 34) ?></span>
        <h3><?= h($c['label']) ?></h3>
        <p class="meta">Version <?= h($c['version']) ?> &middot; <?= h($c['size']) ?></p>
        <p class="req"><?= h($c['requires']) ?></p>
        <?php if ($ok): ?>
          <a class="btn btn-block" href="<?= h(u('download.php?f=' . $k)) ?>" rel="nofollow"><?= icon('download', 18) ?> Download</a>
        <?php else: ?>
          <span class="btn btn-block btn-off" aria-disabled="true">Coming soon</span>
        <?php endif; ?>
        <?php if ($showCounts): ?>
          <?php if ($totals[$k] > 0): ?>
        <p class="count"><b data-count="<?= (int)$totals[$k] ?>"><?= fmt_num($totals[$k]) ?></b> <?= $totals[$k] === 1 ? 'download' : 'downloads' ?></p>
          <?php else: ?>
        <p class="count">Just released</p>
          <?php endif; ?>
        <?php endif; ?>
      </article>
      <?php endforeach; ?>
    </div>

    <div class="tips reveal">
      <div>
        <h4><?= icon('shield', 18) ?> Windows may show a warning</h4>
        <p>The installer is new and not yet code-signed, so Windows can show a blue "Windows protected your PC" box. Click <b>More info</b>, then <b>Run anyway</b>.</p>
      </div>
      <div>
        <h4><?= icon('phone', 18) ?> Installing on Android</h4>
        <p>Open the downloaded file and allow "Install unknown apps" for your browser when asked. If Play Protect asks, choose <b>Install anyway</b>.</p>
      </div>
      <div>
        <h4><?= icon('puzzle', 18) ?> Adding the Chrome button</h4>
        <p>Unzip the file, open the extensions page, switch on Developer mode and choose Load unpacked. <a href="<?= h(u('guide.php#extension')) ?>">See the steps</a>.</p>
      </div>
    </div>
    <?php
    $usesDrive = false;
    foreach ($dl as $c) {
        if (empty($c['url']) && drive_id(isset($c['drive']) ? $c['drive'] : '') !== '') { $usesDrive = true; }
    }
    if ($usesDrive): ?>
    <p class="drive-note reveal">The Windows and Android files are delivered by Google Drive. For big files Google shows a page saying it cannot scan the file for viruses. That is normal: click <b>Download anyway</b>.</p>
    <?php endif; ?>
  </div>
</section>

<section class="sec" id="faq">
  <div class="wrap narrow">
    <div class="sec-head reveal">
      <span class="eyebrow">Questions</span>
      <h2>Good to know</h2>
    </div>
    <div class="faq reveal">
      <details open><summary>Is it really free?<?= icon('chevron', 18) ?></summary><p>Yes. The apps are free to download and use, with no sign-up and no ads inside the app.</p></details>
      <details><summary>Which sites does it work with?<?= icon('chevron', 18) ?></summary><p>YouTube, TikTok, Facebook and Instagram, including playlists and channels on YouTube.</p></details>
      <details><summary>Where do my videos go?<?= icon('chevron', 18) ?></summary><p>They are saved on your own device, in a folder you choose. Nothing is uploaded to this website.</p></details>
      <details><summary>Is it legal to download videos?<?= icon('chevron', 18) ?></summary><p>That depends on the video and where you live. Only save videos you own, that are free to reuse, or that you have permission to keep. Please respect creators and each site's terms.</p></details>
    </div>
    <p class="more"><a href="<?= h(u('faq.php')) ?>">See all questions &rarr;</a></p>
  </div>
</section>

<section class="final">
  <div class="wrap final-in reveal">
    <h2>Ready when you are.</h2>
    <p>Paste a link. Get the video.</p>
    <a class="btn btn-lg" href="#download"><?= icon('download', 20) ?> Download free</a>
  </div>
</section>
<div class="mobile-cta" id="mobile-cta" aria-hidden="true"><a class="btn btn-block" href="#download" tabindex="-1"><?= icon('download', 18) ?> Download free</a></div>
<?php require __DIR__ . '/inc/footer.php'; ?>
