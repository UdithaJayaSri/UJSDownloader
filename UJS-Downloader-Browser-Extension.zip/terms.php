<?php
require_once __DIR__ . '/inc/lib.php';
$page = [
    'title' => 'Terms of use',
    'description' => 'The rules for using UJS Downloader and this website.',
    'path' => 'terms.php',
];
$updated = '25 September 2026';
$email = cfg('contact_email');
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow prose">
    <div class="sec-head left"><span class="eyebrow">Legal</span><h1>Terms of use</h1><p>Last updated: <?= h($updated) ?></p></div>

    <p>By downloading or using <?= h(cfg('site_name')) ?> or this website you agree to these terms. If you do not agree, please do not use them.</p>

    <h2>What it is</h2>
    <p><?= h(cfg('site_name')) ?> is a free tool that helps you save online videos to your own device. It is provided by <?= h(cfg('developer')) ?>.</p>

    <h2>Use it responsibly</h2>
    <ul class="bul">
      <li>Only download content that you own, that is free to reuse (for example under a Creative Commons licence or in the public domain), or that you have clear permission to save.</li>
      <li>You are responsible for following copyright law where you live and the terms of the websites you use it with.</li>
      <li>Do not use the software to infringe others' rights, to redistribute content you do not have rights to, or to break the law.</li>
    </ul>

    <h2>No affiliation</h2>
    <p>This project is independent. It is not affiliated with, endorsed by or sponsored by YouTube, Google, TikTok, Meta, Facebook or Instagram. All product names and logos belong to their owners.</p>

    <h2>No warranty</h2>
    <p>The software and this website are provided "as is", without warranty of any kind. Websites change often, so a feature may stop working at any time. To the fullest extent the law allows, we are not liable for any loss or damage arising from using them.</p>

    <h2>Software licence</h2>
    <p>You may install and use the apps for personal, non-commercial use free of charge. You may not sell them, or re-upload them as your own. The apps use open-source components that stay under their own licences.</p>

    <h2>Copyright complaints</h2>
    <p>UJS Downloader does not host any videos. If you are a rights holder and have a concern about this website, write to <a href="mailto:<?= h($email) ?>"><?= h($email) ?></a> and we will respond.</p>

    <h2>Changes</h2>
    <p>We may update these terms. Continuing to use the software or website after a change means you accept the new terms.</p>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
