<?php
/*
 * Every download button points here: /download.php?f=windows | android | extension
 * It counts the download (once per visitor per 10 minutes, never for bots) and then hands over the file.
 */
require_once __DIR__ . '/inc/lib.php';

$key = isset($_GET['f']) ? preg_replace('/[^a-z]/', '', strtolower((string)$_GET['f'])) : '';
$items = downloads_cfg();

function download_message($status, $title, $text)
{
    global $page;
    http_response_code($status);
    $page = ['title' => $title, 'path' => 'download.php', 'noindex' => true];
    require __DIR__ . '/inc/header.php';
    echo '<section class="sec"><div class="wrap narrow center"><h1>' . h($title) . '</h1><p class="lead">' . h($text) . '</p>'
        . '<p><a class="btn" href="' . h(u('index.php#download')) . '">Back to downloads</a></p></div></section>';
    require __DIR__ . '/inc/footer.php';
    exit;
}

if ($key === '' || !isset($items[$key])) {
    download_message(404, 'File not found', 'That download does not exist. Please pick one from the downloads section.');
}

$item = $items[$key];
if (!download_available($key)) {
    download_message(200, ($item['label'] . ' is coming soon'), 'This download is not published yet. Please check back shortly.');
}

record_download($key);
header('Cache-Control: no-store, max-age=0');

$target = download_target($key);
if ($target[0] === 'url') {
    if (!preg_match('#^https?://#i', $target[1])) {
        download_message(500, 'Download unavailable', 'The download link is not set up correctly yet.');
    }
    header('Location: ' . $target[1], true, 302);
    exit;
}

$file = $target[1];
$name = basename($file);
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
$types = ['zip' => 'application/zip', 'exe' => 'application/vnd.microsoft.portable-executable', 'apk' => 'application/vnd.android.package-archive'];
header('Content-Type: ' . (isset($types[$ext]) ? $types[$ext] : 'application/octet-stream'));
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $name) . '"');
header('Content-Length: ' . filesize($file));
header('X-Content-Type-Options: nosniff');
readfile($file);
exit;
