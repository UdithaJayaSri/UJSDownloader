<?php
require_once __DIR__ . '/inc/lib.php';
$page = [
    'title' => "What's new",
    'description' => 'Release notes for UJS Downloader on Windows, Android and the Chrome button.',
    'path' => 'changelog.php',
];
$releases = [
    ['Windows 1.4.3 &middot; Chrome button 1.2.0', 'Latest', [
        'The dropdown of the YouTube button now opens right under the button and follows it, and flips upward when there is no room.',
        'On YouTube Shorts the button moved to the bottom-right of the video so it no longer covers the play and volume controls.',
    ]],
    ['Windows 1.4.2 &middot; Chrome button 1.1.0', '', [
        'New: a UJS Download button in the row under YouTube videos, next to Share, like other download add-ons.',
        'The floating button on the video is now used only in fullscreen and where there is no action row.',
    ]],
    ['Windows 1.4.1 &middot; Android 1.7.1', '', [
        'Clearer step-by-step instructions for switching on Developer mode in Chrome.',
        'Updated contact details in About.',
    ]],
    ['Windows 1.4.0 &middot; Android 1.7.0', '', [
        'New: pick videos from a playlist or channel, with thumbnails, titles and lengths.',
        'New: trim a clip with a live preview before downloading.',
        'New: clipboard pop-up (Windows) and copied-link offer (Android): download now or add to the queue.',
        'New: the Chrome button is bundled with the Windows installer.',
        'Android now matches the desktop features, including sign-in for videos that need your account, More options, and sharing from History.',
    ]],
];
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow">
    <div class="sec-head left"><span class="eyebrow">Release notes</span><h1>What's new</h1><p>The latest changes to the Windows app, the Android app and the Chrome button.</p></div>
    <div class="timeline">
      <?php foreach ($releases as $r): ?>
      <article class="rel">
        <h2><?= $r[0] ?><?php if ($r[1]): ?> <span class="badge"><?= h($r[1]) ?></span><?php endif; ?></h2>
        <ul class="bul"><?php foreach ($r[2] as $line): ?><li><?= h($line) ?></li><?php endforeach; ?></ul>
      </article>
      <?php endforeach; ?>
    </div>
    <p class="more"><a class="btn" href="<?= h(u('index.php#download')) ?>"><?= icon('download', 18) ?> Get the latest version</a></p>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
