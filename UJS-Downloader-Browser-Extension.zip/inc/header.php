<?php
/*
 * Page header. A page sets $page = ['title'=>..., 'description'=>..., 'path'=>'guide.php', 'nav'=>'guide'] before including this.
 * Optional: 'home' => true, 'noindex' => true, 'jsonld' => [ ... ] (one object or a list).
 */
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/ads.php';

$page = isset($page) && is_array($page) ? $page : [];
$siteName = cfg('site_name');
$path = isset($page['path']) ? $page['path'] : '';
$isHome = !empty($page['home']);
$title = $isHome
    ? $siteName . ': free video downloader for Windows, Android and Chrome'
    : (isset($page['title']) ? $page['title'] . ' | ' . $siteName : $siteName);
$desc = isset($page['description']) ? $page['description']
    : 'Paste a YouTube, TikTok, Facebook or Instagram link and save the video. Free downloader for Windows and Android with playlist picker, trimming, queue and up to 4K quality.';
$canonical = u($path);
$ogImage = u('assets/img/og-image.png');
$nav = isset($page['nav']) ? $page['nav'] : '';
if (empty($page['noindex'])) {
    record_view($path === '' ? 'index.php' : $path);
}
$assetV = function ($f) {
    $p = UJS_ROOT . '/' . $f;
    return '/' . $f . '?v=' . (is_file($p) ? filemtime($p) : 1);
};
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
if (!empty($page['noindex'])) {
    header('X-Robots-Tag: noindex, nofollow');
}
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title><?= h($title) ?></title>
  <meta name="description" content="<?= h($desc) ?>">
  <script>document.documentElement.className += ' js';</script>
  <meta name="theme-color" content="#0a0b10">
<?php if (!empty($page['noindex'])): ?>
  <meta name="robots" content="noindex, nofollow">
<?php else: ?>
  <link rel="canonical" href="<?= h($canonical) ?>">
<?php endif; ?>
  <link rel="icon" href="<?= h(u('favicon.ico')) ?>" sizes="any">
  <link rel="icon" type="image/png" sizes="32x32" href="<?= h(u('assets/img/icon-32.png')) ?>">
  <link rel="apple-touch-icon" href="<?= h(u('assets/img/icon-180.png')) ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= h($siteName) ?>">
  <meta property="og:title" content="<?= h($title) ?>">
  <meta property="og:description" content="<?= h($desc) ?>">
  <meta property="og:url" content="<?= h($canonical) ?>">
  <meta property="og:image" content="<?= h($ogImage) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= h($title) ?>">
  <meta name="twitter:description" content="<?= h($desc) ?>">
  <meta name="twitter:image" content="<?= h($ogImage) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
  <link rel="stylesheet" href="<?= h($assetV('assets/css/style.css')) ?>">
<?php if (!empty($page['jsonld'])):
    $blocks = isset($page['jsonld'][0]) ? $page['jsonld'] : [$page['jsonld']];
    foreach ($blocks as $b): ?>
  <script type="application/ld+json"><?= json_encode($b, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<?php endforeach; endif; ?>
</head>
<body class="<?= $isHome ? 'home' : 'inner' ?>">
<a class="skip" href="#main">Skip to content</a>
<header class="nav" id="top">
  <div class="wrap nav-in">
    <a class="brand" href="<?= h(u('')) ?>" aria-label="<?= h($siteName) ?> home">
      <img src="<?= h(u('assets/img/icon-32.png')) ?>" width="32" height="32" alt="">
      <span><?= h($siteName) ?></span>
    </a>
    <button class="nav-toggle" type="button" aria-label="Menu" aria-expanded="false" aria-controls="nav-links"><?= icon('menu', 22) ?></button>
    <nav class="nav-links" id="nav-links" aria-label="Main">
      <a href="<?= h(u('index.php#features')) ?>">Features</a>
      <a href="<?= h(u('index.php#platforms')) ?>">Everywhere</a>
      <a href="<?= h(u('watch.php')) ?>"<?= $nav === 'watch' ? ' class="on"' : '' ?>>Watch</a>
      <a href="<?= h(u('guide.php')) ?>"<?= $nav === 'guide' ? ' class="on"' : '' ?>>Guide</a>
      <a href="<?= h(u('faq.php')) ?>"<?= $nav === 'faq' ? ' class="on"' : '' ?>>FAQ</a>
      <a class="btn btn-sm" href="<?= h(u('index.php#download')) ?>"><?= icon('download', 16) ?> Download</a>
    </nav>
  </div>
</header>
<main id="main">
