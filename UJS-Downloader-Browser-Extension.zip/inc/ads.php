<?php
/* Advertising helpers. Nothing is printed until 'ads' => 'enabled' is true in config.php and ids are filled in. */
function ads_on()
{
    $a = cfg('ads', []);
    return !empty($a['enabled']) && !empty($a['client']) && strpos($a['client'], '0000000000000000') === false;
}

function ad_slot($name)
{
    if (!ads_on()) {
        return;
    }
    $a = cfg('ads', []);
    $slot = isset($a['slots'][$name]) ? $a['slots'][$name] : '';
    if ($slot === '') {
        return;
    }
    echo '<div class="ad-wrap" data-ad hidden><span class="ad-label">Advertisement</span>'
        . '<ins class="adsbygoogle" style="display:block" data-ad-client="' . h($a['client']) . '" data-ad-slot="' . h($slot)
        . '" data-ad-format="auto" data-full-width-responsive="true"></ins></div>';
}
