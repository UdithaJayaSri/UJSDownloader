<?php
/* Shared helpers: configuration, escaping, anonymous statistics storage. PHP 7.4+ compatible. */
if (!defined('UJS_LIB')) {
    define('UJS_LIB', 1);
    define('UJS_ROOT', dirname(__DIR__));
}

function cfg($key = null, $default = null)
{
    static $c = null;
    if ($c === null) {
        $c = require UJS_ROOT . '/config.php';
        // optional settings for testing on your own PC (never uploaded): see config.local.php
        if (is_file(UJS_ROOT . '/config.local.php')) {
            $c = array_replace_recursive($c, require UJS_ROOT . '/config.local.php');
        }
        @date_default_timezone_set(isset($c['timezone']) ? $c['timezone'] : 'UTC');
    }
    if ($key === null) {
        return $c;
    }
    return array_key_exists($key, $c) ? $c[$key] : $default;
}

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* Full address (used for search engines and sharing tags). */
function site_url($path = '')
{
    return rtrim(cfg('site_url'), '/') . '/' . ltrim($path, '/');
}

/* Root-relative link (works on any domain and when testing locally). */
function u($path = '')
{
    return '/' . ltrim($path, '/');
}

function fmt_num($n)
{
    return number_format((int)$n);
}

function downloads_cfg()
{
    return cfg('downloads', []);
}

/* ---------------------------------------------------------------- visitor helpers */

function is_bot()
{
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    if ($ua === '') {
        return true;
    }
    return (bool)preg_match('/bot|crawl|spider|slurp|facebookexternalhit|preview|monitor|curl|wget|python|httpclient|headless|lighthouse|pingdom|uptime|scanner|fetch/i', $ua);
}

function client_ip()
{
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $v = trim(explode(',', $_SERVER[$k])[0]);
            if ($v !== '') {
                return $v;
            }
        }
    }
    return '0.0.0.0';
}

/* An anonymous fingerprint: a salted hash, never the address itself. */
function visitor_hash($extra = '')
{
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    return sha1(client_ip() . '|' . $ua . '|' . $extra . '|' . cfg('salt', ''));
}

function country_code()
{
    foreach (['HTTP_CF_IPCOUNTRY', 'HTTP_X_COUNTRY_CODE', 'GEOIP_COUNTRY_CODE'] as $k) {
        if (!empty($_SERVER[$k]) && preg_match('/^[A-Za-z]{2}$/', $_SERVER[$k])) {
            return strtoupper($_SERVER[$k]);
        }
    }
    return '';
}

/* ---------------------------------------------------------------- storage */

function store_dir()
{
    $d = UJS_ROOT . '/data';
    if (!is_dir($d)) {
        @mkdir($d, 0755, true);
    }
    return $d;
}

function store_default()
{
    return ['created' => time(), 'downloads' => [], 'recent' => [], 'log' => [], 'logins' => []];
}

/* The data file starts with a PHP line that stops execution, so even if the server were ever to serve it
   as a page nobody could read it. */
const UJS_STORE_HEAD = "<?php http_response_code(403); exit; ?>\n";

function store_read()
{
    $f = store_dir() . '/stats.dat.php';
    if (!is_file($f)) {
        return store_default();
    }
    $raw = @file_get_contents($f);
    if ($raw === false) {
        return store_default();
    }
    $nl = strpos($raw, "\n");
    $data = json_decode($nl === false ? '' : substr($raw, $nl + 1), true);
    return is_array($data) ? array_merge(store_default(), $data) : store_default();
}

/* Runs $fn(array &$data) while holding an exclusive lock, then saves. Returns false if it could not write. */
function store_update($fn)
{
    $lock = @fopen(store_dir() . '/.lock', 'c');
    if ($lock) {
        flock($lock, LOCK_EX);
    }
    $data = store_read();
    $fn($data);
    $ok = @file_put_contents(store_dir() . '/stats.dat.php', UJS_STORE_HEAD . json_encode($data), LOCK_EX) !== false;
    if ($lock) {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
    return $ok;
}

/* ---------------------------------------------------------------- downloads */

/* Adds one to the counter of a file, once per visitor per 10 minutes, never for bots. Returns true if counted. */
function record_download($key)
{
    if (is_bot() || (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'HEAD')) {
        return false;
    }
    $who = visitor_hash($key);
    $cc = country_code();
    $ref = '';
    if (!empty($_SERVER['HTTP_REFERER'])) {
        $ref = (string)parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
    }
    $counted = false;
    store_update(function (&$d) use ($key, $who, $cc, $ref, &$counted) {
        $now = time();
        foreach ($d['recent'] as $k => $t) {
            if ($now - $t > 3600) {
                unset($d['recent'][$k]);
            }
        }
        if (isset($d['recent'][$who]) && $now - $d['recent'][$who] < 600) {
            return;
        }
        $d['recent'][$who] = $now;
        $day = date('Y-m-d');
        if (!isset($d['downloads'][$key])) {
            $d['downloads'][$key] = ['total' => 0, 'days' => []];
        }
        $d['downloads'][$key]['total']++;
        $d['downloads'][$key]['days'][$day] = (isset($d['downloads'][$key]['days'][$day]) ? $d['downloads'][$key]['days'][$day] : 0) + 1;
        $cut = date('Y-m-d', $now - 400 * 86400);
        foreach ($d['downloads'][$key]['days'] as $dd => $n) {
            if ($dd < $cut) {
                unset($d['downloads'][$key]['days'][$dd]);
            }
        }
        array_unshift($d['log'], [$now, $key, $cc, $ref]);
        $d['log'] = array_slice($d['log'], 0, 300);
        $counted = true;
    });
    return $counted;
}

function download_total($key)
{
    $d = store_read();
    return isset($d['downloads'][$key]['total']) ? (int)$d['downloads'][$key]['total'] : 0;
}

function all_download_totals()
{
    $d = store_read();
    $out = [];
    foreach (array_keys(downloads_cfg()) as $k) {
        $out[$k] = isset($d['downloads'][$k]['total']) ? (int)$d['downloads'][$k]['total'] : 0;
    }
    return $out;
}

/* Accepts a Google Drive share link or just the file id, returns the id (or ''). */
function drive_id($v)
{
    $v = trim((string)$v);
    if ($v === '') {
        return '';
    }
    if (preg_match('#/d/([A-Za-z0-9_-]{15,})#', $v, $m) || preg_match('#[?&]id=([A-Za-z0-9_-]{15,})#', $v, $m)) {
        return $m[1];
    }
    return preg_match('/^[A-Za-z0-9_-]{15,}$/', $v) ? $v : '';
}

/* Where a download really comes from: ['url', address] for an outside link, ['local', path] for a file on this site, or null. */
function download_target($key)
{
    $c = downloads_cfg();
    if (!isset($c[$key])) {
        return null;
    }
    $it = $c[$key];
    if (!empty($it['url'])) {
        return ['url', $it['url']];
    }
    $id = drive_id(isset($it['drive']) ? $it['drive'] : '');
    if ($id !== '') {
        // 'view' opens Drive's own page with its download button (always works); the default goes straight to the file.
        if (isset($it['drive_mode']) && $it['drive_mode'] === 'view') {
            return ['url', 'https://drive.google.com/file/d/' . $id . '/view?usp=sharing'];
        }
        return ['url', 'https://drive.usercontent.google.com/download?id=' . $id . '&export=download&confirm=t'];
    }
    if (!empty($it['local']) && is_file(UJS_ROOT . '/' . $it['local'])) {
        return ['local', UJS_ROOT . '/' . $it['local']];
    }
    return null;
}

function download_available($key)
{
    return download_target($key) !== null;
}

/* ---------------------------------------------------------------- page views (append-only log, cheap to write) */

function record_view($path)
{
    if (is_bot()) {
        return;
    }
    $file = store_dir() . '/views-' . date('Y-m') . '.log';
    $line = time() . ',' . substr(visitor_hash('view'), 0, 10) . ',' . preg_replace('/[^A-Za-z0-9_.\-\/]/', '', $path) . "\n";
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

/* Reads the last $days days of page views: [day => ['views' => n, 'visitors' => n]]. */
function views_by_day($days = 30)
{
    $out = [];
    for ($i = $days - 1; $i >= 0; $i--) {
        $out[date('Y-m-d', time() - $i * 86400)] = ['views' => 0, 'visitors' => 0, 'seen' => []];
    }
    $months = array_unique([date('Y-m'), date('Y-m', time() - 31 * 86400)]);
    foreach ($months as $m) {
        $f = store_dir() . '/views-' . $m . '.log';
        if (!is_file($f)) {
            continue;
        }
        $fh = @fopen($f, 'r');
        if (!$fh) {
            continue;
        }
        while (($line = fgets($fh)) !== false) {
            $p = explode(',', trim($line));
            if (count($p) < 2) {
                continue;
            }
            $day = date('Y-m-d', (int)$p[0]);
            if (!isset($out[$day])) {
                continue;
            }
            $out[$day]['views']++;
            $out[$day]['seen'][$p[1]] = 1;
        }
        fclose($fh);
    }
    foreach ($out as $day => $v) {
        $out[$day]['visitors'] = count($v['seen']);
        unset($out[$day]['seen']);
    }
    return $out;
}
