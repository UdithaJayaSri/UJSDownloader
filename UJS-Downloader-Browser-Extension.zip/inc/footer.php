</main>
<?php
$waNum = preg_replace('/\D/', '', (string)cfg('contact_whatsapp', ''));
$adsCfg = cfg('ads', []);
$js = [
    'ads'    => ads_on(),
    'client' => ads_on() ? $adsCfg['client'] : '',
    'base'   => rtrim(cfg('site_url'), '/'),
];
$assetV2 = function ($f) {
    $p = UJS_ROOT . '/' . $f;
    return '/' . $f . '?v=' . (is_file($p) ? filemtime($p) : 1);
};
?>
<?php ad_slot('footer'); ?>
<footer class="foot">
  <div class="wrap foot-grid">
    <div class="foot-about">
      <a class="brand" href="<?= h(u('')) ?>">
        <img src="<?= h(u('assets/img/icon-32.png')) ?>" width="32" height="32" alt="">
        <span><?= h(cfg('site_name')) ?></span>
      </a>
      <p>A free video downloader for Windows and Android, with a one-click button for Chrome. Made in Sri Lanka by <a href="<?= h(cfg('developer_url')) ?>" target="_blank" rel="noopener"><?= h(cfg('developer')) ?></a>.</p>
    </div>
    <div>
      <h4>Get it</h4>
      <a href="<?= h(u('index.php#download')) ?>">Downloads</a>
      <a href="<?= h(u('index.php#features')) ?>">Features</a>
      <a href="<?= h(u('guide.php')) ?>">Install guide</a>
      <a href="<?= h(u('changelog.php')) ?>">What's new</a>
    </div>
    <div>
      <h4>Help</h4>
      <a href="<?= h(u('faq.php')) ?>">FAQ</a>
      <a href="<?= h(u('contact.php')) ?>">Contact</a>
      <a href="<?= h(cfg('developer_url')) ?>" target="_blank" rel="noopener">Developer portfolio</a>
<?php if (cfg('contact_email')): ?>
      <a href="mailto:<?= h(cfg('contact_email')) ?>"><?= h(cfg('contact_email')) ?></a>
<?php endif; ?>
<?php if ($waNum): ?>
      <a href="https://wa.me/<?= h($waNum) ?>" rel="noopener">WhatsApp</a>
<?php endif; ?>
    </div>
    <div>
      <h4>Legal</h4>
      <a href="<?= h(u('privacy.php')) ?>">Privacy policy</a>
      <a href="<?= h(u('terms.php')) ?>">Terms of use</a>
    </div>
  </div>
  <div class="wrap foot-bottom">
    <p>&copy; <?= date('Y') ?> <?= h(cfg('site_name')) ?>. Not affiliated with, endorsed by or sponsored by YouTube, Google, TikTok, Meta, Facebook or Instagram. Those names belong to their owners. Only download content you own or have permission to save.</p>
  </div>
</footer>
<?php if (ads_on()): ?>
<div class="consent" id="consent" role="dialog" aria-label="Cookie notice" hidden>
  <p>We show ads to keep this site free. Ad partners may use cookies. You can allow personalised ads, or choose non-personalised ads. See our <a href="<?= h(u('privacy.php')) ?>">privacy policy</a>.</p>
  <div class="consent-btns">
    <button type="button" class="btn btn-sm" data-consent="all">Allow</button>
    <button type="button" class="btn btn-sm btn-ghost" data-consent="basic">Non-personalised only</button>
  </div>
</div>
<?php endif; ?>
<script>window.UJS = <?= json_encode($js) ?>;</script>
<script src="<?= h($assetV2('assets/js/app.js')) ?>" defer></script>
</body>
</html>
