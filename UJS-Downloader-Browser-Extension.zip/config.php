<?php
/*
 * UJS Downloader website: the only file you normally need to edit.
 * Upload the whole "website" folder to the "htdocs" folder of your InfinityFree account.
 */
return [
    // ---- Basics -----------------------------------------------------------------------------
    'site_name'   => 'UJS Downloader',
    'site_url'    => 'https://ujs.free.je',          // no trailing slash
    'tagline'     => 'Paste a link. Get the video.',
    'developer'   => 'Uditha Jaya Sri',
    'developer_url' => 'https://udithajayasri.github.io/Portfolio/',   // shown as the developer profile link
    'timezone'    => 'Asia/Colombo',

    // ---- Contact (shown on the Contact page and in the footer) -----------------------------------
    'contact_email'    => 'ujs.live@gmail.com',
    // WhatsApp number in international format without + or spaces (94 = Sri Lanka). Leave '' to hide it.
    'contact_whatsapp' => '94771227793',

    // ---- Admin (the private statistics page: /stats.php) ------------------------------------------
    // CHANGE BOTH before you go live. The password is only ever read by the server.
    'admin_password' => 'MP9l8iYWkPB9NtPhVl',
    // Any long random text; it makes the anonymous visitor fingerprints impossible to reverse.
    'salt'           => '3a0fdacd6a411100c4f0aa867920668d75f0893db6494911',

    // ---- Downloads ---------------------------------------------------------------------------------
    // Every button on the site goes through /download.php?f=KEY, which adds 1 to that file's counter
    // and then sends the visitor to the file.
    //
    //   'url'   = where the file really lives (a full https:// link). Big files (the .exe and .apk are
    //             100 MB+) should NOT live on InfinityFree: put them on GitHub Releases (free, up to 2 GB
    //             per file) and paste the direct link here. See README-DEPLOY.md.
    //   'drive' = OR paste a Google Drive share link (or just the file id). The file must be shared as
    //             "Anyone with the link". 'drive_mode' => 'view' opens Drive's own download page instead of
    //             going straight to the file (use it if direct downloads ever stop working).
    //   'local' = a small file kept on this site (relative to this folder), used when the two above are empty.
    //
    // Leave both empty and the card shows "Coming soon" instead of a button.
    'show_public_counts' => true,     // show "12,345 downloads" on the public page
    'downloads' => [
        'windows' => [
            'label'    => 'Windows',
            'file'     => 'UJS Downloader Setup 1.4.3.exe',
            'version'  => '1.4.3',
            'size'     => '113 MB',
            'requires' => 'Windows 10 or 11 (64-bit)',
            'url'      => '',
            'drive'    => 'https://drive.google.com/file/d/1eAP5t3EmWUCGf7pIqUzWlHqhGKeJdX_3/view?usp=sharing',   // e.g. 'https://drive.google.com/file/d/1AbC.../view?usp=sharing'
            'local'    => '',
        ],
        'android' => [
            'label'    => 'Android',
            'file'     => 'UJS-Downloader-Android-1.7.1.apk',
            'version'  => '1.7.1',
            'size'     => '100 MB',
            'requires' => 'Android 7.0 or newer',
            'url'      => '',
            'drive'    => 'https://drive.google.com/file/d/1eyuCBAkDzadtPbluHR69QmZKg0q9Jggu/view?usp=sharing',
            'local'    => '',
        ],
        'extension' => [
            'label'    => 'Browser button',
            'file'     => 'UJS-Downloader-Browser-Extension.zip',
            'version'  => '1.2.0',
            'size'     => '23 KB',
            'requires' => 'Chrome, Edge or Brave',
            'url'      => '',
            'local'    => 'downloads/UJS-Downloader-Browser-Extension.zip',
        ],
    ],

    // ---- Videos (the /watch.php page and the teaser on the home page) -------------------------------------
    // 'file' is a video kept on this site. To use YouTube instead (recommended if you upload the video there),
    // put the video id in 'youtube' (the part after v=) and the player will load it from YouTube.
    'videos' => [
        'tour'  => ['title' => 'Full tour', 'length' => '5:11', 'seconds' => 311,
                    'file' => 'assets/media/tour.mp4', 'poster' => 'assets/media/tour-poster.jpg', 'youtube' => ''],
        'short' => ['title' => '30-second version', 'length' => '0:26', 'seconds' => 26,
                    'file' => 'assets/media/short.mp4', 'poster' => 'assets/media/short-poster.jpg', 'youtube' => ''],
    ],

    // ---- Advertising (later) ---------------------------------------------------------------------------
    // When you are approved, set 'enabled' => true and paste your publisher id and ad unit ids.
    // Until then no ad code and no ad space appears anywhere. A cookie notice is shown once ads are on.
    'ads' => [
        'enabled' => false,
        'client'  => 'ca-pub-0000000000000000',
        'slots'   => [
            'top'    => '',   // wide banner under the header
            'inline' => '',   // in-content unit between sections
            'footer' => '',   // above the footer
        ],
    ],
];
