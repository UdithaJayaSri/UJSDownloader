<?php
/* Private statistics page. Log in with the admin_password from config.php. Nothing here is linked from the public site. */
require_once __DIR__ . '/inc/lib.php';

session_name('ujsadm');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
session_start();
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: stats.php');
    exit;
}

$page = ['title' => 'Statistics', 'path' => 'stats.php', 'noindex' => true];

/* ------------------------------------------------------------------ login */
if (empty($_SESSION['ok'])) {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    $err = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $who = visitor_hash('login');
        $blocked = false;
        $store = store_read();
        if (isset($store['logins'][$who]) && $store['logins'][$who][0] >= 8 && time() - $store['logins'][$who][1] < 900) {
            $blocked = true;
        }
        if ($blocked) {
            $err = 'Too many attempts. Please wait 15 minutes.';
        } elseif (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], (string)$_POST['csrf'])) {
            $err = 'The form expired. Please try again.';
        } elseif (hash_equals((string)cfg('admin_password', ''), (string)(isset($_POST['password']) ? $_POST['password'] : '')) && cfg('admin_password', '') !== '') {
            session_regenerate_id(true);
            $_SESSION['ok'] = 1;
            store_update(function (&$d) use ($who) { unset($d['logins'][$who]); });
            header('Location: stats.php');
            exit;
        } else {
            store_update(function (&$d) use ($who) {
                $now = time();
                foreach ($d['logins'] as $k => $v) { if ($now - $v[1] > 900) { unset($d['logins'][$k]); } }
                if (isset($d['logins'][$who])) { $d['logins'][$who][0]++; } else { $d['logins'][$who] = [1, $now]; }
            });
            usleep(700000);
            $err = 'Wrong password.';
        }
    }
    require __DIR__ . '/inc/header.php';
    ?>
    <section class="sec"><div class="wrap narrow">
      <form class="login" method="post" autocomplete="off">
        <h1>Statistics</h1>
        <p>Private page. Enter the admin password from <code>config.php</code>.</p>
        <?php if ($err): ?><p class="err"><?= h($err) ?></p><?php endif; ?>
        <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
        <label for="pw">Password</label>
        <input id="pw" name="password" type="password" required autofocus>
        <button class="btn btn-block" type="submit">Sign in</button>
      </form>
    </div></section>
    <?php
    require __DIR__ . '/inc/footer.php';
    exit;
}

/* ------------------------------------------------------------------ numbers */
$items = downloads_cfg();
$keys = array_keys($items);
$d = store_read();
$days = [];
for ($i = 29; $i >= 0; $i--) {
    $days[] = date('Y-m-d', time() - $i * 86400);
}
$today = date('Y-m-d');
$per = [];
foreach ($keys as $k) {
    $rows = isset($d['downloads'][$k]['days']) ? $d['downloads'][$k]['days'] : [];
    $sum = function ($n) use ($rows) {
        $t = 0;
        for ($i = 0; $i < $n; $i++) {
            $t += isset($rows[date('Y-m-d', time() - $i * 86400)]) ? $rows[date('Y-m-d', time() - $i * 86400)] : 0;
        }
        return $t;
    };
    $per[$k] = [
        'total' => isset($d['downloads'][$k]['total']) ? (int)$d['downloads'][$k]['total'] : 0,
        'today' => isset($rows[$today]) ? $rows[$today] : 0,
        'd7' => $sum(7),
        'd30' => $sum(30),
        'rows' => $rows,
    ];
}
$views = views_by_day(30);
$viewSum = 0;
$visSum = 0;
foreach ($views as $v) { $viewSum += $v['views']; $visSum += $v['visitors']; }
$grand = 0; $grandToday = 0; $grand7 = 0; $grand30 = 0;
foreach ($per as $p) { $grand += $p['total']; $grandToday += $p['today']; $grand7 += $p['d7']; $grand30 += $p['d30']; }

/* CSV export */
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ujs-stats-' . $today . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, array_merge(['date'], $keys, ['page_views', 'visitors']));
    foreach ($days as $day) {
        $row = [$day];
        foreach ($keys as $k) { $row[] = isset($per[$k]['rows'][$day]) ? $per[$k]['rows'][$day] : 0; }
        $row[] = $views[$day]['views'];
        $row[] = $views[$day]['visitors'];
        fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

$colors = ['windows' => '#ff5a3c', 'android' => '#7c5cff', 'extension' => '#22c9a4'];
$fallback = ['#f5b942', '#3aa0ff', '#e05aa0'];
$col = function ($k, $i) use ($colors, $fallback) { return isset($colors[$k]) ? $colors[$k] : $fallback[$i % 3]; };

function svg_bars($days, $series, $height = 200)
{
    // $series: [ [label, color, [day => value]] , ... ] stacked
    $w = 720; $pad = 28; $n = count($days);
    $max = 1;
    foreach ($days as $day) {
        $t = 0;
        foreach ($series as $s) { $t += isset($s[2][$day]) ? $s[2][$day] : 0; }
        $max = max($max, $t);
    }
    $bw = ($w - $pad) / $n;
    $svg = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . ($height + 26) . '" role="img" aria-label="Chart">';
    for ($g = 0; $g <= 4; $g++) {
        $y = 8 + ($height - 8) * $g / 4;
        $svg .= '<line x1="' . $pad . '" x2="' . $w . '" y1="' . $y . '" y2="' . $y . '" stroke="rgba(255,255,255,.08)"/>';
        $svg .= '<text x="0" y="' . ($y + 4) . '" fill="#7d8598" font-size="11">' . round($max * (4 - $g) / 4) . '</text>';
    }
    foreach ($days as $i => $day) {
        $x = $pad + $i * $bw + $bw * 0.16;
        $yy = $height;
        foreach ($series as $s) {
            $v = isset($s[2][$day]) ? $s[2][$day] : 0;
            if ($v <= 0) { continue; }
            $hh = ($height - 8) * $v / $max;
            $yy -= $hh;
            $svg .= '<rect x="' . round($x, 1) . '" y="' . round($yy, 1) . '" width="' . round($bw * 0.68, 1) . '" height="' . round($hh, 1) . '" rx="2" fill="' . $s[1] . '"><title>' . h($day . ': ' . $s[0] . ' ' . $v) . '</title></rect>';
        }
    }
    $svg .= '<text x="' . $pad . '" y="' . ($height + 18) . '" fill="#7d8598" font-size="11">' . h(date('M j', strtotime($days[0]))) . '</text>';
    $svg .= '<text x="' . $w . '" y="' . ($height + 18) . '" text-anchor="end" fill="#7d8598" font-size="11">' . h(date('M j', strtotime($days[$n - 1]))) . '</text>';
    return $svg . '</svg>';
}

$dlSeries = []; $i = 0;
foreach ($keys as $k) { $dlSeries[] = [$items[$k]['label'], $col($k, $i++), $per[$k]['rows']]; }
$viewRows = []; $visRows = [];
foreach ($views as $day => $v) { $viewRows[$day] = $v['views']; $visRows[$day] = $v['visitors']; }

require __DIR__ . '/inc/header.php';
?>
<section class="sec admin"><div class="wrap">
  <div class="admin-head">
    <div><h1>Statistics</h1><p class="muted">Last 30 days &middot; times are Sri Lanka time &middot; bots are not counted</p></div>
    <div class="admin-actions"><a class="btn btn-sm btn-ghost" href="stats.php?export=csv">Export CSV</a> <a class="btn btn-sm btn-ghost" href="stats.php?logout=1">Sign out</a></div>
  </div>

  <div class="kpis">
    <div class="kpi"><span>Total downloads</span><b><?= fmt_num($grand) ?></b></div>
    <div class="kpi"><span>Today</span><b><?= fmt_num($grandToday) ?></b></div>
    <div class="kpi"><span>Last 7 days</span><b><?= fmt_num($grand7) ?></b></div>
    <div class="kpi"><span>Last 30 days</span><b><?= fmt_num($grand30) ?></b></div>
    <div class="kpi"><span>Page views (30 d)</span><b><?= fmt_num($viewSum) ?></b></div>
    <div class="kpi"><span>Visitors (30 d)</span><b><?= fmt_num($visSum) ?></b></div>
  </div>

  <h2>Downloads per day</h2>
  <div class="panelbox">
    <?= svg_bars($days, $dlSeries) ?>
    <p class="legend"><?php $i = 0; foreach ($keys as $k): ?><span><i style="background:<?= h($col($k, $i++)) ?>"></i><?= h($items[$k]['label']) ?></span><?php endforeach; ?></p>
  </div>

  <h2>Each download</h2>
  <div class="tablewrap"><table>
    <thead><tr><th>File</th><th>Version</th><th>Today</th><th>7 days</th><th>30 days</th><th>All time</th><th>Link</th></tr></thead>
    <tbody>
    <?php foreach ($keys as $k): ?>
      <tr>
        <td><b><?= h($items[$k]['label']) ?></b><br><small><?= h($items[$k]['file']) ?></small></td>
        <td><?= h($items[$k]['version']) ?></td>
        <td><?= fmt_num($per[$k]['today']) ?></td>
        <td><?= fmt_num($per[$k]['d7']) ?></td>
        <td><?= fmt_num($per[$k]['d30']) ?></td>
        <td><b><?= fmt_num($per[$k]['total']) ?></b></td>
        <td><?= download_available($k) ? '<span class="ok">live</span>' : '<span class="warn">not set</span>' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>

  <div class="two">
    <div>
      <h2>Page views per day</h2>
      <div class="panelbox"><?= svg_bars($days, [['Views', '#ff9d7a', $viewRows]], 150) ?></div>
    </div>
    <div>
      <h2>Visitors per day</h2>
      <div class="panelbox"><?= svg_bars($days, [['Visitors', '#7c5cff', $visRows]], 150) ?></div>
    </div>
  </div>

  <h2>Latest downloads</h2>
  <div class="tablewrap"><table>
    <thead><tr><th>When</th><th>File</th><th>Country</th><th>Came from</th></tr></thead>
    <tbody>
    <?php if (!$d['log']): ?><tr><td colspan="4" class="muted">No downloads yet.</td></tr><?php endif; ?>
    <?php foreach (array_slice($d['log'], 0, 40) as $r): ?>
      <tr><td><?= h(date('Y-m-d H:i', $r[0])) ?></td><td><?= h(isset($items[$r[1]]) ? $items[$r[1]]['label'] : $r[1]) ?></td><td><?= h($r[2] !== '' ? $r[2] : '-') ?></td><td><?= h(isset($r[3]) && $r[3] !== '' ? $r[3] : 'direct') ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>

  <h2>Ad income estimate</h2>
  <div class="panelbox estimator" data-views="<?= (int)$viewSum ?>">
    <p class="muted">Only a rough guide. Real income depends on your ad network, your visitors' countries and how many click. RPM = income per 1,000 page views.</p>
    <label>Page views per month <input id="est-views" type="number" min="0" value="<?= (int)max($viewSum, 1000) ?>"></label>
    <label>RPM in US dollars <input id="est-rpm" type="number" min="0" step="0.1" value="1.5"></label>
    <p class="est">About <b id="est-out">$0</b> per month</p>
  </div>
  <script>
  (function () {
    var v = document.getElementById('est-views'), r = document.getElementById('est-rpm'), o = document.getElementById('est-out');
    function calc() { o.textContent = '$' + (((+v.value || 0) / 1000) * (+r.value || 0)).toFixed(2); }
    v.addEventListener('input', calc); r.addEventListener('input', calc); calc();
  })();
  </script>
</div></section>
<?php require __DIR__ . '/inc/footer.php'; ?>
