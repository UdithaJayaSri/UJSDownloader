<?php
require_once __DIR__ . '/inc/lib.php';

$faq = [
    ['Is UJS Downloader really free?', 'Yes. The Windows app, the Android app and the Chrome button are free to download and use. There is no sign-up, and there are no ads inside the apps.'],
    ['Which websites does it work with?', 'YouTube, TikTok, Facebook and Instagram. On YouTube it also handles whole playlists and channels.'],
    ['Where are my videos saved?', 'On your own device, in a folder you choose. On Windows the default is your Downloads folder; on Android it is Downloads/UJSDownloader. Videos can be organised into a folder per site and channel.'],
    ['Does it upload my videos or links anywhere?', 'No. The apps talk to the video sites directly from your device. This website only counts how many times each app was downloaded, without storing who you are.'],
    ['What quality can I download?', 'The best the video offers, up to 4K, or a lower quality if you want a smaller file. You can also save audio only as MP3, with the cover art and title added.'],
    ['Can I download only part of a video?', 'Yes. Drag the two handles to choose the start and end, and preview the clip before you save it.'],
    ['Can I download private videos?', 'Only ones your own account is allowed to see. Sign in once inside the app; your session stays on your device.'],
    ['Why does Windows show a "protected your PC" warning?', 'The installer is new and is not yet code-signed, which is what Windows checks for. Click More info, then Run anyway. If you prefer, scan the file with your antivirus first.'],
    ['Why does Android ask about unknown apps?', 'The app is installed from this website instead of the Play Store, so Android asks you to allow it. Choose Install anyway if Play Protect shows a notice.'],
    ['How does the Chrome button work?', 'It adds an orange UJS Download button in the row under a YouTube video. One click sends that video to the Windows app. Follow the steps in the install guide to switch it on once.'],
    ['Is it legal to download videos?', 'It depends on the video and on where you live. Only save videos you made, that are free to reuse, or that you have permission to keep. Please respect creators and the terms of each website.'],
    ['Something stopped working. What now?', 'Sites change often, so update to the newest version first. If it still fails, contact us with the type of link and what you saw and we will look into it.'],
];

$ld = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => []];
foreach ($faq as $q) {
    $ld['mainEntity'][] = ['@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $q[1]]];
}
$page = [
    'title' => 'Frequently asked questions',
    'description' => 'Answers about UJS Downloader: which sites it supports, quality, trimming, playlists, safety, Windows and Android warnings, and legality.',
    'path' => 'faq.php',
    'nav' => 'faq',
    'jsonld' => $ld,
];
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow">
    <div class="sec-head left"><span class="eyebrow">FAQ</span><h1>Frequently asked questions</h1><p>Short answers to the things people ask most.</p></div>
    <div class="faq">
      <?php foreach ($faq as $i => $q): ?>
      <details<?= $i === 0 ? ' open' : '' ?>><summary><?= h($q[0]) ?><?= icon('chevron', 18) ?></summary><p><?= h($q[1]) ?></p></details>
      <?php endforeach; ?>
    </div>
    <p class="more">Still have a question? <a href="<?= h(u('contact.php')) ?>">Get in touch</a>.</p>
  </div>
</section>
<?php ad_slot('inline'); require __DIR__ . '/inc/footer.php'; ?>
