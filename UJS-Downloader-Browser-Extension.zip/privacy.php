<?php
require_once __DIR__ . '/inc/lib.php';
$page = [
    'title' => 'Privacy policy',
    'description' => 'What UJS Downloader and this website do and do not collect about you.',
    'path' => 'privacy.php',
];
$updated = '25 September 2026';
$email = cfg('contact_email');
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap narrow prose">
    <div class="sec-head left"><span class="eyebrow">Legal</span><h1>Privacy policy</h1><p>Last updated: <?= h($updated) ?></p></div>

    <p>This policy explains what <?= h(cfg('site_name')) ?> (the apps and this website, <?= h(cfg('site_url')) ?>) collects, and what it does not. We keep it short because there is very little to say.</p>

    <h2>The apps</h2>
    <ul class="bul">
      <li>The Windows app, the Android app and the Chrome button run on your device. The links you paste and the videos you save are not sent to us.</li>
      <li>The apps contact the video websites directly to read a video's details and download it, the same way your browser would.</li>
      <li>Your download history, settings and any sign-in session are stored only on your device. You can delete them from the app or by uninstalling it.</li>
      <li>The apps do not contain advertising or analytics.</li>
      <li>The Chrome button talks only to the UJS Downloader app on your own computer (address 127.0.0.1). It does not send data to any server.</li>
    </ul>

    <h2>This website</h2>
    <ul class="bul">
      <li><b>Download counts.</b> When you click a download button we add one to a counter for that file. To avoid counting the same person many times we keep a one-way, salted fingerprint of your connection for up to an hour; your IP address is never stored. If our host tells us your country, we may keep the two-letter country code and the website you came from.</li>
      <li><b>Page views.</b> We count page views and roughly how many different visitors we have per day, using the same kind of one-way fingerprint. This helps us see what is useful.</li>
      <li><b>Cookies.</b> This website does not set cookies for visitors. The private admin page uses a session cookie for the site owner only.</li>
      <li><b>Fonts.</b> Pages load the Inter font from Google Fonts, which means your browser contacts Google to fetch it.</li>
      <li><b>Hosting.</b> Our hosting provider keeps ordinary server logs (such as IP address and pages requested) for security and operation.</li>
    </ul>

    <h2>Advertising</h2>
    <p>We may show advertising on this website in future. If we do, third-party ad partners, including Google, may use cookies or similar technologies to show ads based on your visits to this and other websites. We will ask for your choice with a notice before ads load. Google's use of advertising cookies lets it and its partners show ads based on your visit to this site and/or other sites. You can opt out of personalised advertising at <a href="https://adssettings.google.com" rel="noopener">Google Ads Settings</a> or learn more at <a href="https://www.aboutads.info" rel="noopener">aboutads.info</a>. Ads never appear inside the apps.</p>

    <h2>Your choices and rights</h2>
    <p>You can browse this site without giving us any personal information. If you want to ask a question about privacy, or ask us to remove anything you believe we hold about you, write to <a href="mailto:<?= h($email) ?>"><?= h($email) ?></a>.</p>

    <h2>Children</h2>
    <p>This website is not directed at children under 13 and we do not knowingly collect information from them.</p>

    <h2>Changes</h2>
    <p>If this policy changes we will update the date at the top of this page.</p>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
