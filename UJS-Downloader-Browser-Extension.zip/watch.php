<?php
require_once __DIR__ . '/inc/lib.php';
$videos = cfg('videos', []);
$tour = isset($videos['tour']) ? $videos['tour'] : null;
$short = isset($videos['short']) ? $videos['short'] : null;

// chapters of the full tour: [start second, label]
$chapters = [
    [0, 'Intro'], [9, 'Install'], [14, 'Add the browser button'], [39, 'Playlist picker'], [67, 'Trim and preview'],
    [91, 'Quality and download'], [114, 'The queue'], [129, 'Clipboard pop-up'], [139, 'History'],
    [149, 'The button on YouTube'], [181, 'The Android app'], [300, 'Wrap-up'],
];
$mmss = function ($s) { return sprintf('%d:%02d', intdiv($s, 60), $s % 60); };

$page = [
    'title' => 'Watch: UJS Downloader in action',
    'description' => 'See how UJS Downloader works: a five-minute tour of the Windows app, the Chrome button under YouTube videos and the Android app, plus a 30-second version.',
    'path' => 'watch.php',
    'nav' => 'watch',
];
if ($tour) {
    $page['jsonld'] = [
        '@context' => 'https://schema.org',
        '@type' => 'VideoObject',
        'name' => 'UJS Downloader: full tour',
        'description' => 'A tour of UJS Downloader on Windows, in Chrome and on Android.',
        'thumbnailUrl' => [site_url($tour['poster'])],
        'uploadDate' => '2026-09-25',
        'duration' => 'PT' . intdiv($tour['seconds'], 60) . 'M' . ($tour['seconds'] % 60) . 'S',
        'contentUrl' => empty($tour['youtube']) ? site_url($tour['file']) : 'https://www.youtube.com/watch?v=' . $tour['youtube'],
    ];
}
require __DIR__ . '/inc/header.php';

/* One player: the video kept on this site, or a YouTube video that only loads when the visitor taps play. */
function player_html($v, $id)
{
    if (!empty($v['youtube'])) {
        return '<button type="button" class="yt-lite" data-yt="' . h($v['youtube']) . '" data-title="' . h($v['title']) . '" style="background-image:url(https://i.ytimg.com/vi/' . h($v['youtube']) . '/hqdefault.jpg)" aria-label="Play ' . h($v['title']) . '"><span class="play">' . icon('play', 34) . '</span></button>';
    }
    return '<video id="' . h($id) . '" controls playsinline preload="metadata" poster="' . h(u($v['poster'])) . '" aria-label="' . h($v['title']) . '">'
        . '<source src="' . h(u($v['file'])) . '" type="video/mp4">'
        . 'Your browser cannot play this video.</video>';
}
?>
<section class="sec">
  <div class="wrap">
    <div class="sec-head">
      <span class="eyebrow">Watch</span>
      <h1>See UJS Downloader in action</h1>
      <p>A short tour, with a voice-over, of everything it can do.</p>
    </div>

    <div class="watch-grid">
      <div class="watch-main">
        <?php if ($tour): ?>
        <div class="player"><?= player_html($tour, 'tour-video') ?></div>
        <p class="player-meta"><b><?= h($tour['title']) ?></b> &middot; <?= h($tour['length']) ?> &middot; Windows, Chrome and Android</p>

        <?php if (empty($tour['youtube'])): ?>
        <h2 class="chapters-title">Jump to a part</h2>
        <ol class="chapters">
          <?php foreach ($chapters as $c): ?>
          <li><button type="button" data-seek="<?= (int)$c[0] ?>"><time><?= h($mmss($c[0])) ?></time> <?= h($c[1]) ?></button></li>
          <?php endforeach; ?>
        </ol>
        <?php endif; ?>

        <details class="transcript">
          <summary>Read what the voice-over says</summary>
          <p>UJS Downloader. Download from YouTube, TikTok, Facebook and Instagram. Setup is one double click, and it installs everything. On first launch the app offers to add its button to your browser: turn on Developer mode, click Load unpacked and choose the folder shown in the app. Paste any link; a playlist or channel opens a picker with thumbnails, titles and lengths, for up to three hundred videos. Got a single video? Trim it first: drag the handles, watch a live preview and set the start and end exactly where you want them. Pick a quality up to 4K, or audio only as MP3 with cover art, then download. Everything waits in the queue, and History keeps every finished download. On YouTube the UJS button sits right under the video; hide or show it any time with Alt Shift U. Then the Android app: the same picker and trimming, and when you copy a link the app offers to download it. Paste a link. Get the video.</p>
        </details>
        <?php endif; ?>
      </div>

      <?php if ($short): ?>
      <aside class="short-col">
        <div class="phone-mock">
          <?php if (!empty($short['youtube'])): ?>
            <?= player_html($short, 'short-video') ?>
          <?php else: ?>
            <video id="short-video" controls playsinline preload="none" poster="<?= h(u($short['poster'])) ?>" aria-label="<?= h($short['title']) ?>"><source src="<?= h(u($short['file'])) ?>" type="video/mp4"></video>
          <?php endif; ?>
        </div>
        <h3>Short on time?</h3>
        <p>The <?= h($short['length']) ?> version: what it is and what it does.</p>
      </aside>
      <?php endif; ?>
    </div>

    <div class="final-in" style="margin-top:56px">
      <h2>Like what you see?</h2>
      <p>It is free. Paste a link. Get the video.</p>
      <a class="btn btn-lg" href="<?= h(u('index.php#download')) ?>"><?= icon('download', 20) ?> Download free</a>
    </div>
  </div>
</section>
<?php ad_slot('inline'); require __DIR__ . '/inc/footer.php'; ?>
