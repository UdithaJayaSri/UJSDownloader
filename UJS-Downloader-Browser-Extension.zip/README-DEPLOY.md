# UJS Downloader website: how to put it online (InfinityFree)

Everything in this folder is ready to upload. It is plain PHP (works on PHP 7.4 to 8.x), needs **no database**, and keeps its
counters in a small private file inside `data/`.

## 1. Before you upload: edit `config.php` (5 minutes)

| Setting | What to do |
|---|---|
| `admin_password` | **Change it.** This is the password for `https://ujs.free.je/stats.php`. |
| `salt` | Change it to any long random text. |
| `contact_email`, `contact_whatsapp` | Shown in the footer and on the Contact page. Empty a value to hide it. |
| `downloads` → `windows` / `android` → `url` | Where the big files really live (see step 3). |

## 2. Upload

1. In the InfinityFree control panel open **Software → PHP Config** and pick PHP 8.x (7.4 also works).
2. Connect with an FTP program (FileZilla) using the FTP details from your InfinityFree account, and open the **`htdocs`** folder.
3. Delete the default `index2.html` file in `htdocs`, then upload the **contents** of this folder (not the folder itself) into `htdocs`.
   Keep the hidden files: `.htaccess`, `data/.htaccess`, `inc/.htaccess`.
4. Make sure the `data` folder is writable (normally it already is; if the stats page shows nothing after a download, set the folder permission to 755 or 775).
5. Open `https://ujs.free.je/`.

## 3. The .exe and .apk (100 MB+): do not keep them on InfinityFree

As far as I know, free hosts like InfinityFree limit file sizes and do not want to be used as file storage, so the two big files
should live somewhere made for it. **GitHub Releases** is free and allows 2 GB per file. Your site still counts every download,
because the buttons point to `download.php`, which adds 1 and then sends the visitor on to the real file.

1. Create a **public** GitHub repository, for example `ujs-downloads` (it only needs to hold releases, not your source code).
2. Rename your files so they never change name between versions:
   `UJS Downloader Setup 1.4.3.exe` → `UJS-Downloader-Setup.exe`, and `UJS-Downloader-Android-1.7.1.apk` → `UJS-Downloader.apk`.
3. **Releases → Create a new release**, tag `v1.4.3`, attach both files, publish.
4. In `config.php` set:

   ```php
   'windows' => [ ..., 'url' => 'https://github.com/YOUR-NAME/ujs-downloads/releases/latest/download/UJS-Downloader-Setup.exe' ],
   'android' => [ ..., 'url' => 'https://github.com/YOUR-NAME/ujs-downloads/releases/latest/download/UJS-Downloader.apk' ],
   ```
   With the `latest/download` address you never need to touch the config again: for each new version just publish a new release with the same file names.
   Also update `version` and `size` in `config.php`, and add a note to `changelog.php`.
5. Optional but wise: scan each file on virustotal.com once. Unsigned installers sometimes get a false alarm, and it is better to know first.

### Option B: Google Drive (already set up for the Windows and Android files)

Instead of GitHub you can keep the big files on Google Drive. In `config.php` paste the Drive share link into `'drive'`
(the file must be shared as **Anyone with the link**). The site turns it into Google's direct-download address, so visitors get
the file straight away, and your counters still count every click.

* Check that the file on Drive is really the newest one: the Windows installer is 113 MB and the Android app is 100 MB.
* When you publish a new version, upload it to Drive, share it the same way, and paste the new link.
* Drive can temporarily block a very popular file ("too many users have downloaded this file recently"). If that ever
  happens, switch to GitHub Releases (option A), or set `'drive_mode' => 'view'` to send people to Drive's own download page.
* **Never share the website package (this folder or its zip) with "Anyone with the link".** `config.php` holds your admin
  password. Keep that zip private, and only put the finished app files on Drive.

The small browser-button file lives on the site (`downloads/UJS-Downloader-Browser-Extension.zip`). To update it, upload the new zip with the same name and change `version` in `config.php`.

## 4. Check that counting works

1. Open the site in a normal browser and click a download button.
2. Open `https://ujs.free.je/stats.php`, sign in, and you should see the download.
3. Clicking the same button again within 10 minutes is deliberately **not** counted twice, and bots are ignored.
4. Delete `data/stats.dat.php` and `data/views-*.log` to reset the counters (for example after your own tests).

## 5. What the dashboard shows (`/stats.php`)

Total, today, 7-day and 30-day downloads for each file, a 30-day chart, page views and visitors per day, the latest downloads
(time, file, country when the host provides it, and where the visitor came from), a CSV export, and a small income estimator.
Nothing personal is stored: only counts and a one-way fingerprint that is kept for at most an hour.

## 6. Getting ready for advertising later

The site is already prepared:
* Ad slots (`top`, `inline`, `footer`) exist but print nothing until you switch ads on.
* Privacy policy, Terms, Contact, FAQ, Guide and What's new pages exist (ad networks look for these).
* A cookie notice appears automatically once ads are on, and ads only load after the visitor chooses.
* `ads.txt` is a placeholder for your publisher line.

To switch on, edit `config.php`: `'enabled' => true`, your `client` id and the three `slots`.

**Please read this before you count on ad income:**
* **Google AdSense is likely to refuse a site whose main purpose is downloading videos from YouTube and similar sites.** In my understanding its policies do not allow it. Please read the current AdSense program policies before you invest effort, and do not assume approval.
* AdSense generally also wants a domain you own. A free subdomain such as `ujs.free.je` is normally not accepted. A real domain costs about 10 dollars a year, and InfinityFree lets you connect your own domain for free. Nothing on this site is tied to the domain: change `site_url` in `config.php`, and the addresses in `robots.txt` and `sitemap.xml`.
* Other ad networks have different rules. Check each one's policy on downloader tools before you sign up.
* Other income ideas that do not depend on an ad network: a Buy Me a Coffee / donation link, or affiliate links.

## 7. Keep it healthy

* After you upload a new release, update `version` and `size` in `config.php`.
* Take a copy of `data/stats.dat.php` now and then (it holds all your counts).
* If Google Search Console asks, submit `https://ujs.free.je/sitemap.xml`.
