<?php
require_once __DIR__ . '/inc/lib.php';
$page = [
    'title' => 'Install guide for Windows, Android and Chrome',
    'description' => 'Step by step: install UJS Downloader on Windows and Android, add the Chrome button under YouTube videos, and download your first video.',
    'path' => 'guide.php',
    'nav' => 'guide',
    'jsonld' => [
        '@context' => 'https://schema.org',
        '@type' => 'HowTo',
        'name' => 'How to install UJS Downloader and save your first video',
        'step' => [
            ['@type' => 'HowToStep', 'name' => 'Download the app', 'text' => 'Download the Windows installer or the Android app from the downloads section.'],
            ['@type' => 'HowToStep', 'name' => 'Install it', 'text' => 'Run the installer on Windows, or open the file on Android and allow the install.'],
            ['@type' => 'HowToStep', 'name' => 'Paste a link', 'text' => 'Copy a video link, paste it into the app and press Check Video.'],
            ['@type' => 'HowToStep', 'name' => 'Download', 'text' => 'Choose the quality, optionally trim the clip, and press Download.'],
        ],
    ],
];
require __DIR__ . '/inc/header.php';
?>
<section class="sec">
  <div class="wrap prose-wrap">
    <div class="sec-head left">
      <span class="eyebrow">Guide</span>
      <h1>Install and use UJS Downloader</h1>
      <p>Everything from the first click to your first saved video.</p>
      <p class="jump"><a href="#windows">Windows</a> <a href="#android">Android</a> <a href="#extension">Chrome button</a> <a href="#use">Using the app</a> <a href="#help">If something goes wrong</a></p>
    </div>

    <div class="prose">
      <h2 id="windows"><?= icon('monitor', 26) ?> Windows</h2>
      <ol class="steplist">
        <li><b>Download</b> <em>UJS Downloader Setup</em> from the <a href="<?= h(u('index.php#download')) ?>">downloads section</a>.</li>
        <li><b>Double-click the file.</b> It installs just for you and needs no administrator password. It takes a few seconds.</li>
        <li>If Windows shows a blue <b>"Windows protected your PC"</b> box, click <b>More info</b>, then <b>Run anyway</b>. This happens because the installer is new and not yet code-signed.</li>
        <li>The app opens by itself. It also offers to add the <b>Chrome button</b>: see below.</li>
      </ol>

      <h2 id="android"><?= icon('phone', 26) ?> Android</h2>
      <ol class="steplist">
        <li><b>Download</b> the Android app from the <a href="<?= h(u('index.php#download')) ?>">downloads section</a> (Android 7.0 or newer).</li>
        <li><b>Open the downloaded file.</b> When Android asks, allow "Install unknown apps" for your browser.</li>
        <li>If Google Play Protect shows a notice, choose <b>Install anyway</b>.</li>
        <li>Open <b>UJS Downloader</b> and allow notifications, so you can see progress while it downloads in the background.</li>
      </ol>

      <h2 id="extension"><?= icon('puzzle', 26) ?> The Chrome button (under YouTube videos)</h2>
      <p>The button sends the video you are watching to the Windows app. It works in Chrome, Edge and Brave. The Windows installer already includes it; you only need to switch it on once, because browsers do not let any installer add an extension for you.</p>
      <ol class="steplist">
        <li>Open the <b>Google Chrome</b> browser.</li>
        <li>Click the <b>three vertical dots</b> in the top right corner.</li>
        <li>Hover over <b>Extensions</b>, then click <b>Manage Extensions</b>.</li>
        <li>Find the <b>Developer mode</b> toggle in the top-right corner of the extensions page and turn it on.</li>
        <li>Click <b>Load unpacked</b> and choose the extension folder. The app shows you the exact folder and turns green when it is connected.</li>
      </ol>
      <p>Prefer to install it on its own? <a href="<?= h(u('download.php?f=extension')) ?>" rel="nofollow">Download the extension</a>, unzip it, and choose the unzipped folder in step 5. The Windows app must be installed too, because that is where the videos are saved.</p>
      <figure class="shot"><img loading="lazy" src="<?= h(u('assets/img/app-guide.png')) ?>" width="1180" height="760" alt="The setup guide inside the UJS Downloader Windows app"><figcaption>The setup guide inside the Windows app.</figcaption></figure>
      <p>Open any YouTube video and you will see the orange <b>UJS Download</b> button in the row with Like, Share and Save. Click the arrow next to it for more choices: choose quality and trim, download right away, add to the queue, or hide the button. <b>Alt+Shift+U</b> hides or shows it on any page.</p>

      <h2 id="use">Saving your first video</h2>
      <ol class="steplist">
        <li><b>Copy the link</b> of a video from YouTube, TikTok, Facebook or Instagram.</li>
        <li><b>Paste it</b> into UJS Downloader and press <b>Check Video</b>. On a phone the app can offer to do this the moment you copy a link.</li>
        <li><b>Choose what you want:</b> best quality, a lower quality, or audio only (MP3). Drag the two handles to trim just a part of the video, and use the preview to check it.</li>
        <li>Press <b>Download</b>, or <b>Add to Queue</b> to keep going. Finished videos appear in <b>History</b>, where you can open, share or remove them.</li>
      </ol>
      <p><b>Playlists and channels:</b> paste a playlist or channel link and the picker opens. Filter by title, tick the videos you want (long-press or Shift-click to tick a range) and add them to the queue.</p>

      <h2 id="help">If something goes wrong</h2>
      <ul class="bul">
        <li><b>A video will not download.</b> Update to the latest version first, because the sites change often. If it still fails, the video may be private, age-restricted or blocked in your country.</li>
        <li><b>The button is missing under a YouTube video.</b> Open the extensions page, click the reload arrow on UJS Downloader, then refresh the YouTube tab.</li>
        <li><b>The button says the app is not running.</b> It starts the app for you; if that does not work, open UJS Downloader once from the Start menu.</li>
        <li><b>Still stuck?</b> <a href="<?= h(u('contact.php')) ?>">Contact us</a> and tell us the link type and what you saw.</li>
      </ul>
    </div>
  </div>
</section>
<?php ad_slot('inline'); require __DIR__ . '/inc/footer.php'; ?>
